<?php 
get_header();

get_template_part('template-parts/content', 'none');

get_footer();