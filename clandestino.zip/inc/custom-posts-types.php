<?php
// add_action( 'init', 'badiario_farmacias', 0 );

// function badiario_farmacias() {

// 	$labels = array(
// 		'name'                  => 'Farmacias',
// 		'singular_name'         => 'Farmacia',
// 		'menu_name'             => 'Farmacias de turno',
// 		'name_admin_bar'        => 'Farmacia de turno',
// 		// 'archives'              => 'Estilos de lampara',
// 		'all_items'             => 'Todas las farmacias',
// 		'add_new_item'          => 'Agregar nueva farmacia',
// 		'add_new'               => 'Agregar farmacia',
// 		'new_item'              => 'Nueva farmacia',
// 		'edit_item'             => 'Editar farmacia',
// 		'update_item'           => 'Actualizar farmacia',
// 	);
// 	$args = array(
// 		'label'                 => 'Farmacia',
// 		'description'           => 'Lista de farmacias de turno',
// 		'labels'                => $labels,
// 		'supports'              => array( 'title' ),
// 		'hierarchical'          => false,
// 		'public'                => true,
// 		'show_ui'               => true,
// 		'show_in_menu'          => true,
// 		'menu_position'         => 5,
// 		'menu_icon'   => 'dashicons-plus',
// 		'show_in_admin_bar'     => true,
// 		'show_in_nav_menus'     => false,
// 		'can_export'            => true,
// 		// 'has_archive'           => true,
// 		'exclude_from_search'   => true,
// 		'publicly_queryable'    => false,
// 		'rewrite'               => true,
// 		'capability_type'       => 'page',
// 	);
// 	register_post_type( 'farmacias', $args );

// }
