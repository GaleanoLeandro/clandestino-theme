<div class="container">
    <div class="py-3 d-flex justify-content-center align-items-center">
        <h1 class="m-5 text-w-3 text-1">
            Content not found
        </h1>
    </div>
</div>